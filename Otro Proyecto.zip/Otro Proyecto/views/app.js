import express from "express";
import { engine } from "express-handlebars";

const app = express();

// Configurar Handlebars
app.engine(".hbs", engine({
  extname: ".hbs",
  helpers: {
    rango: function (num) {
      return Array(num).fill(1); // crea un array con 'num' elementos
    }
  }
}));
app.set("view engine", ".hbs");
app.set("views", "./views");

// Datos de ejemplo
const deportes = [
  { nombre: "Fútbol", descripcion: "Deporte en equipo con balón.", requisitos: "Balón, cancha, equipo.", ranking: 5 },
  { nombre: "Natación", descripcion: "Deporte acuático individual.", requisitos: "Piscina, traje de baño.", ranking: 4 },
  { nombre: "Ciclismo", descripcion: "Deporte con bicicleta.", requisitos: "Bicicleta, casco, pista.", ranking: 4.5 },
];

// Ruta principal
app.get("/", (req, res) => {
  res.render("home", { deportes });
});

app.listen(3000, () => console.log("Servidor en http://localhost:3000"));
