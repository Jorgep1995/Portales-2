const express = require('express');
const exphbs  = require('express-handlebars');
const path = require('path');

const app = express();
const PORT = 3000;

// Configuración de Handlebars
app.engine('hbs', exphbs.engine({
    extname: 'hbs',
    defaultLayout: 'main',
    layoutsDir: __dirname + '/views/layouts/'
}));
app.set('view engine', 'hbs');
app.set('views', path.join(__dirname, 'views'));

// Archivos estáticos (CSS, imágenes, JS)
app.use(express.static(path.join(__dirname, 'public')));

// Contexto con imágenes
const galleryImages = [];
for (let i = 1; i <= 15; i++) {
    galleryImages.push({ src: `/images/img${i}.jpg`, alt: `Imagen ${i}` });
}

// Ruta principal
app.get('/', (req, res) => {
    res.render('gallery', { images: galleryImages });
});

app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
