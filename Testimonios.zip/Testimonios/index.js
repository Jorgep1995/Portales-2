// Asegúrate de incluir Handlebars en el index.html
document.addEventListener("DOMContentLoaded", async () => {
  // Registrar el parcial
  const parcialSrc = await fetch("partials/testimonial.hbs").then(res => res.text());
  Handlebars.registerPartial("testimonial", parcialSrc);

  // Cargar plantilla principal (contenedor)
  const templateSource = `
    <section class="panel-testimonios">
      <h2>Testimonios</h2>
      <div class="testimonios-contenedor">
        {{#each testimonios}}
          {{> testimonial}}
        {{/each}}
      </div>
    </section>
  `;

  const template = Handlebars.compile(templateSource);

  // Inyectar datos del JSON
  const html = template(testimoniosData);

  // Renderización en DOM
  document.getElementById("app").innerHTML = html;
});
