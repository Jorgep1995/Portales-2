const testimoniosData = {
  testimonios: [
    {
      nombre: "Jawi Méndez",
      cargo: "Desarrollado Frontend",
      mensaje: "El curso fue increíble, aprendí muchísimo sobre buenas prácticas.",
      imagen: "https://i.pravatar.cc/100?img=1"
    },
    {
      nombre: "Alberto del Río",
      cargo: "Diseñador UX/UI",
      mensaje: "La plataforma es muy intuitiva y fácil de usar.",
      imagen: "https://i.pravatar.cc/100?img=2"
    },
    {
      nombre: "Eleazar Gómez",
      cargo: "Project Manager",
      mensaje: "Excelente experiencia, totalmente recomendable.",
      imagen: "https://i.pravatar.cc/100?img=3"
    }
  ]
};
